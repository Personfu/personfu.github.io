# Source provenance and notices

The upstream implementation and its history come from Paul Gardiner's psVoodoo repository at `https://git.code.sf.net/p/psvoodoo/psVoodoo`.

Many implementation files identify Paul Gardiner as the initial developer and state that the software is released under the GNU Library or Lesser General Public License (LGPL). These notices, the original copyright information, and version-resource author credits are retained.

The `sdk2_*.h` headers now come from the later open-source 3dfx Glide tree at revision `2f226f0f9225ce8ee83e6a4a7042981e719d19ee`. They expressly use the separate 3DFX GLIDE Source Code General Public License (SPDX: `Glide`), reproduced in [licenses/Glide.txt](licenses/Glide.txt). Their original notices are preserved and local adaptations are marked. See [header provenance](docs/glide-headers.md) for exact files, hashes, changes and validation.

This replaces the older headers carrying proprietary wording; it does not claim that those historical files were relicensed or that the wrapper's LGPL applies to the replacement headers. Keep the applicable license, notices and corresponding-source materials when distributing. Combined-license and App Store distribution review remain separate work.

The new build tooling and public-ABI test programs are maintained with the fork. The new `tests/header-abi.cpp` has its own MIT notice in [licenses/MIT.txt](licenses/MIT.txt); this does not relicense other files. No game installers, game assets, nGlide DLLs, or other proprietary comparison binaries are included.
