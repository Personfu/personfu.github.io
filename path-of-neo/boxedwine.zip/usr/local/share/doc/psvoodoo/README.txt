psVoodoo for Boxedwine, base revision 67fcb0a0eb1be9c5f77d04250ad715b2f481754b
Source: https://github.com/danoon2/psVoodoo.git
Built with the LLVM-MinGW toolchain pinned in filesystem_wine11.json.
The source archive contains the patched sources used to build this DLL.
build.json records the upstream base, patch hashes, toolchain pin, and source hashes.
Its revision is a local build snapshot, not an upstream commit.
Rebuild with Boxedwine tools/buildWine/build_filesystem.py and filesystem_wine11.json.
To use the standalone upstream builder, extract the source archive and initialize
a local Git repository: git init; git add .; git commit -m "Build snapshot"
Then run python3 tools/build.py --toolchain /path/to/llvm-mingw/bin --output /path/to/new-build --d3d9-only
On Linux, supply D3D9.h and D3DX9.h include aliases as the filesystem builder does.
Patch files, notices, and license texts are included here.
