# Glide 2 header provenance

The five `sdk2_*.h` files were replaced on September 14, 2026 with headers from
the open-source 3dfx Glide tree maintained at
<https://github.com/sezero/glide>, revision
`2f226f0f9225ce8ee83e6a4a7042981e719d19ee`.

These source files expressly name the **3DFX GLIDE Source Code General Public
License**, SPDX identifier `Glide`. The full, unmodified license is in
[`licenses/Glide.txt`](../licenses/Glide.txt). It is a separate license from
the wrapper implementation's LGPL notices. This replacement does not assert
that the older proprietary-worded SDK files were retroactively relicensed.

[`glide-headers.json`](glide-headers.json) records the upstream path and SHA-256
for each original file, the local file hash, and every adaptation. The original
3dfx notices remain intact. The adapted files carry dated modification notices.

| Local file | Upstream file | Adaptation |
| --- | --- | --- |
| `sdk2_3dfx.h` | `swlibs/fxmisc/3dfx.h` | C-linkage stdcall exports for `CPPDLL` |
| `sdk2_glide.h` | `glide2x/sst1/glide/src/glide.h` | Local include filenames; psVoodoo's internal 32-bit texture formats |
| `sdk2_glideutl.h` | `glide2x/sst1/glide/src/glideutl.h` | None; byte-identical to upstream |
| `sdk2_glidesys.h` | `glide2x/sst1/glide/src/glidesys.h` | None; byte-identical to upstream |
| `sdk2_sst1vid.h` | `glide2x/sst1/init/sst1vid.h` | None; byte-identical to upstream |

The active target remains Win32 Glide 2 with two texture units. The internal
ARGB/ABGR 8888 values preserve psVoodoo's texture conversion; they do not claim
to add those hardware formats to Glide 2. Historical simulator/SST2 compilation
options in the superseded headers are not supported wrapper targets.

## Validation

`tests/header-abi.cpp` checks fixed Win32 scalar widths, record sizes and offsets,
texture/display constants, and representative stdcall signatures. The build
tool compiles it when `--build-probes` is requested. It is checked with and
without `CPPDLL`, covering the DLL and a consumer's declarations. The same
contract was compiled against the preceding headers during migration.

The September 14 migration builds used LLVM-MinGW 20260908, i686/UCRT, and
`--d3d9-only`. All 369 export records and every PE section other than `.buildid`
were identical to the preceding source built with the same toolchain.
The load-only check and framebuffer color, clip-order, detail-blending and
W-depth regressions passed with Wine 11 / filesystem 11 and WineD3D OpenGL.
The depth check covered 648 samples with zero mismatches. The runtime checks
used the previously validated Boxedwine diagnostic runtime and a disposable
prefix; a separate attempt with a fresh prefix and current Debug runtime
timed out before the loading check. These checks do not establish the cause
of that startup timeout or constitute a new game-playthrough.

Upstream header and license whitespace is intentionally preserved, including
trailing spaces, so unmodified file hashes remain comparable to upstream.

Before releasing a DLL from a header update, compare exports and executable
code with a build of the preceding revision and run the public rendering
regressions in `tests/README.md`. Keep the full source and build manifest
associated with the binary. The header check alone is not a game test.

## Distribution materials

Keep the license, notices, modified header sources, and source/build provenance
with distributions as required by the applicable terms. The build output
contains `NOTICE.md`, `licenses/Glide.txt`, and the tracked source snapshot.
The license has its own source-delivery, notice, modification and trademark
conditions; it is not MIT/BSD and is not the GNU GPL. No right to use 3dfx's
trademarks is being granted by this project.

This resolves the provenance of the current replacement headers. It does not
clear historical distributions, establish compatibility of all combined
licenses with App Store terms, or complete the wrapper/compiler-runtime source
and notice audit. Those remain part of the distribution review.
